<?php

// https://www.amazon.com/dp/B00EWCUK98/
// simple product (without variations)

// https://www.amazon.com/dp/B074JXC8HP/
// product with 1 level of variation props

// https://www.amazon.com/dp/B0769XD5YC/
// product with 2 levels of variation props

// https://www.amazon.com/dp/B079TJZXTR/
// product with 3 levels of variation props

// https://www.amazon.com/dp/B00DDXYC6O/
// product with list price & sale price (aka cut price) - it's a variation child
